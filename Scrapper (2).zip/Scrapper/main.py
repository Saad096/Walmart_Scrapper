import json
from WebScrapper import *
import logging

logging.basicConfig()


def get_post_search():
    web = DataScrap()
    data_ = web.scrap_data(keyword="fresh onion", limit=1000)
    web.close()
    return data_


data = get_post_search()
with open("data.json", "w") as write_file:
    json.dump(data, write_file, indent=4)


print("OK")
