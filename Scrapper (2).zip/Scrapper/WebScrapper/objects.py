import os
from dataclasses import dataclass
from time import sleep
from selenium.webdriver import Chrome
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import logging

logging.basicConfig()


@dataclass
class Scraper:
    driver: Chrome = None
    WAIT_FOR_ELEMENT_TIMEOUT = 5
    TOP_CARD = "pv-top-card"

    @staticmethod
    def wait(duration):
        sleep(int(duration))

    def initialize(self):
        temp = self.driver
        if temp:
            temp.maximize_window()
        try:
            if os.getenv("CHROMEDRIVER") is None:
                driver_path = os.path.join(
                    os.path.dirname(__file__), "drivers/chromedriver"
                )
            else:
                driver_path = os.getenv("CHROMEDRIVER")
            options = Options()
            # options.add_argument('--headless')
            # options.add_argument('--disable-gpu')
            options.add_argument('--disable-notifications')
            options.add_argument('start-maximized')
            return webdriver.Chrome(service=Service(driver_path), chrome_options=options)
        except Exception as e:
            logging.error("Error! creating webdriver", exc_info=e)
            return webdriver.Chrome()

    def scroll_to_bottom(self, class_name: str or None = None, num: int = 0):
        try:
            if class_name:
                self.driver.execute_script(
                    f"my_div = document.getElementsByClassName('{class_name}')[{num}];"
                    f"my_div.scrollTo(0,my_div.scrollHeight);"
                )
            else:
                self.driver.execute_script(
                    "window.scrollTo(0, document.body.scrollHeight);"
                )
        except Exception as e:
            logging.error("Error! scroll_to_bottom", exc_info=e)
            pass
