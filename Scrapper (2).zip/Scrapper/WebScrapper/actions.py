import getpass
import pickle
from . import constants as c
from selenium.webdriver.common.by import By
from time import sleep
import os
import logging

logging.basicConfig()


def __prompt_email_password():
    u = input("Email: ")
    p = getpass.getpass(prompt="Password: ")
    return u, p


def page_has_loaded(driver):
    page_state = driver.execute_script('return document.readyState;')
    return page_state == 'complete'


def load_cookies(driver):
    try:
        driver.get('https://www.tridge.com/')
        if os.path.isfile(c.COOKIE_FILE_NAME):
            with open(c.COOKIE_FILE_NAME, 'rb') as file:
                cookies = pickle.load(file)
                for cookie in cookies:
                    driver.add_cookie(cookie)
                driver.get('https://www.tridge.com/')
                sleep(2)
    except Exception as e:
        logging.error("Error load_cookies", exc_info=e)


def save_cookies(driver):
    pickle.dump(driver.get_cookies(), open(c.COOKIE_FILE_NAME, 'wb'))


def login(driver, timeout=10):

    load_cookies(driver=driver)
    driver.get("https://www.tridge.com/login")
    counter = 0
    while counter < 5:
        element = driver.find_elements(By.XPATH, c.USER_EMAIL)
        if len(element) == 0:
            return
        counter = counter + 1
        sleep(1)
    email = "talk2saadalam@gmail.com"
    password = "123"

    driver.get("https://www.tridge.com/login")

    try:
        email_elem = driver.find_element(By.XPATH, c.USER_EMAIL)
        email_elem.send_keys(email)
        sleep(2)
    except Exception as e:
        logging.error("Error! email_elem.send_keys", exc_info=e)
    password_elem = driver.find_element(By.XPATH, c.USER_PASSWORD)
    password_elem.send_keys(password)
    sleep(2)
    password_elem.submit()

    counters = 0
    while counters < timeout:
        sleep(1)
        element = driver.find_elements(By.XPATH, c.USER_EMAIL)
        if len(element) == 0:
            break
        else:
            pass
        counters = counters + 1
    save_cookies(driver)
