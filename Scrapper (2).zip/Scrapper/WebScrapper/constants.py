
COOKIE_FILE_NAME = 'cookie.pkl'
REMEMBER_PROMPT = 'remember-me-prompt__form-primary'
USER_EMAIL = "//input[@type='email']"
USER_PASSWORD = "//input[@type='password']"
