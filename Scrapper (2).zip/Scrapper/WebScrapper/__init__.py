from .web_scrapper import DataScrap
