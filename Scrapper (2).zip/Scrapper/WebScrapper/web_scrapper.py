import logging
from .objects import Scraper
from WebScrapper import actions
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

logging.basicConfig()


class DataScrap(Scraper):
    url = None
    driver = None
    limit = None
    logged_in = False

    def __init__(
            self,
            url="https://www.tridge.com/",
            driver=None
    ):
        self.url = url
        self.driver = driver
        self.limit = None

        if self.driver is None:
            self.driver = self.initialize()

        actions.login(self.driver)

    def close(self):
        if self.driver:
            self.driver.quit()

    def scrap_data(self, keyword: str = "", limit: int or None = None):
        self.url = f"{self.url}prices"
        self.driver.get(self.url)
        self.wait(5)
        self.limit = limit
        but = self.driver.find_element(By.XPATH, "//button[contains(@class,'selector')]")
        if but:
            action = ActionChains(self.driver)
            action.click(but)
            action.perform()
        self.wait(2)
        but = self.driver.find_element(By.XPATH, "//input[@placeholder='Search']")
        if but:
            but.send_keys(keyword)
        self.wait(2)
        selections = self.driver.find_elements(By.XPATH, '//div[@role="menu-item"]')
        if selections:
            action = ActionChains(self.driver)
            action.click(selections[0])
            action.perform()
        self.scroll_to_bottom()
        self.wait(2)
        cookies_but = self.driver.find_elements(By.XPATH, '//button')
        for c_b in cookies_but:
            if "Accept Cookies" == c_b.text:
                action = ActionChains(self.driver)
                action.click(c_b)
                action.click()

        print("OK")

        results = []

        while True:
            self.scroll_to_bottom(class_name="simplebar-content-wrapper", num=5)
            while True:
                self.wait(1)
                elements = self.driver.find_elements(By.XPATH, '//thead')
                if len(elements) == 0:
                    continue
                else:
                    break
            table = self.driver.find_element(By.XPATH, '//table')
            t_head = table.find_element(By.XPATH, './/thead')
            t_head_data = t_head.find_elements(By.XPATH, './/th')
            t_head_data = [t.text for t in t_head_data]
            country, region, variety, unit = t_head_data[2:6]
            t_head_data = t_head_data[6:]
            t_body = table.find_element(By.XPATH, './/tbody')
            t_body_records = t_body.find_elements(By.XPATH, 'tr')
            for record in t_body_records:
                record_data = record.find_elements(By.XPATH, 'td')
                record_data = [r.text for r in record_data]
                country_data, region_data, variety_data, unit_data = record_data[2:6]
                record_data = record_data[6:]

                for date_, price_ in zip(t_head_data, record_data):
                    results.append(
                        {
                            country: country_data,
                            region: region_data,
                            variety: variety_data,
                            unit: unit_data,
                            "Date": date_,
                            "Price": price_
                        }
                    )
                    if len(results) >= limit:
                        return results

            but_next = self.driver.find_elements(By.XPATH, "//button[contains(@class,'toned secondary')]")
            if len(but_next) >= 2:
                action = ActionChains(self.driver)
                action.click(but_next[1])
                action.perform()
            else:
                break
        return results
